var count = 0;  // record counter

//display active user and his/her roles
var curUser = gs.getUser(); 
gs.­print(­curUser.­getFullName()); 
gs.­print(­curUser.­getUserRoles());
gs.print('');

//Display Table Values
function displayValues() {
count = 0;
var pre = new GlideRecord('u_top_secret_stuff');
pre.query();
while (pre.next()) {
  count+++
  gs.log('Identifier: ' + pre.u_identifier + ' --  (update indicator): ' + pre.u_i_was_here);
  }
 gs.log('records read: ' + count);
 gs.log('');
}

//Display table values "before"
gs.log('table PRE values');
displayValues();

//Read/Write Top Secret stuff table
count = 0;
var gr = new GlideRecord('u_top_secret_stuff');
gr.query();
//loop thru records and indicate an update
while (gr.next()) {
  
//1    if (!gr.canRead())
//2        continue;
//3    gs.log('canRead!');
//4    if (!gr.canWrite())
//5        continue;
//6    gs.log('canWrite!');
//7    if (!gr.u_i_was_here.canRead() || !gr.u_i_was_here.canWrite())
//8       gr.u_i_was_here = null;
//9    else
      gr.u_i_was_here = 'true';
     
      if (gr.update())  
          gs.log(gr.u_identifier + ' record updated **')
          count++;
}
gs.log('total records updated: ' + count);
gs.log('');

//Display table values "after"
gs.log('table POST values');
displayValues();
