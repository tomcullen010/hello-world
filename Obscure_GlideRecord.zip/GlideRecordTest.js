//initialize variables
var inc_count = 0;           //count loop iterations
var myIncident_count = 0;    //save GlideRecord values
var myIncident_num = 0;      //         "
var myPriority = 0;          //         "
var myShort_descr = '';      //         "
var myAssigned_to = 0;       //         "

//log values for test/debug
function printValues(code_position) {
    gs.log(' *****  ' + code_position + '  *****');
    gs.log('Incident_num: ' + myIncident_num + ' (type = ' + typeof myIncident_num + ')');
    gs.log('priority: ' + myPriority + ' (type = ' + typeof myPriority + ')');
    gs.log('short_descritption: ' + myShort_descr + ' (type = ' + typeof myShort_descr + ')');
    gs.log('assigned_to: ' + myAssigned_to + ' (type = ' + typeof myAssigned_to + ')');
    gs.log('incident count: ' + inc_count + ' (type = ' + typeof inc_count + ')');
    gs.log('');
}

//loop through active GlideRecords
var gr = new GlideRecord('incident');
gr.addQuery('active', true);
gr.orderBy('opened_at');
gr.query();
while (gr.next()) {
  inc_count++;
  if (gr.sys_id == 'd7158da0c0a8016700eef46c8d1f3661') {
    
//--> Using Object.name notation
//1    myIncident_num = gr.number;
//2    myPriority = gr.priority;
//3    myShort_descr = gr.short_description;
//4    myAssigned_to = gr.assigned_to;

//--> Using getValue method
//5  myIncident_num = gr.getValue('number');
//6  myPriority = gr.getValue('priority');
//7  myShort_descr = gr.getValue('short_description');
//8  myAssigned_to = gr.getValue('assigned_to');
  
    printValues('in loop ...');
  }
 }

printValues('outside loop !');